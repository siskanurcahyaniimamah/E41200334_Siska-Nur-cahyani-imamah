package com.example.detailactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnMove = findViewById(R.id.btnMove);
        Button btnShare = findViewById(R.id.btnShare);

        btnMove.setOnClickListener(new vi.OnClickListener() {
            @Override
            public void onClick(View v) {

<em>  // Perintah Intent Explicit pindah halaman ke activity_detail
</em>               startActivity(new Intent(MainActivity.this, DetailActivity.class));
            }
        });

        btnShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

<em>               // Perintah Intent Implicit untuk share ke sosmed
</em>               Intent intent = new Intent(Intent.ACTION_SEND);

<em>               // Membawa data / pesan yang ingin dishare
</em>               intent.putExtra(intent.EXTRA_TEXT,"Hallo saya share ke sosial media");
                intent.setType("text/plain");

<em>               // Menjalankan perintah Intent Implicit
</em>               startActivity(Intent.createChooser(intent,"Share to :"));
            }
        });

    }
}